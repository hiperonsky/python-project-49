### Hexlet tests and linter status:
[![Actions Status](https://github.com/hiperonsky/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/hiperonsky/python-project-49/actions)  
[![Maintainability](https://api.codeclimate.com/v1/badges/a3a5dc8fc46d3b7c3a69/maintainability)](https://codeclimate.com/github/hiperonsky/python-project-49/maintainability)  
Package install: https://asciinema.org/a/Td2NHxMYvcI8ZV3F9TQGXp2hQ  
Game launch: https://asciinema.org/a/91AOVjWkxd3TdCdojQEy5qbVt  
Calc game launch: https://asciinema.org/a/gemDQYqfVsJb3fm8AXhUXRSpl  
GCD game launch: https://asciinema.org/a/xUluz7clArYz11nLO65ObNYL1  
