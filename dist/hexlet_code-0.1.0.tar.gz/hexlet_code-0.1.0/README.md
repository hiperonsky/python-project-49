### Hexlet tests and linter status:
[![Actions Status](https://github.com/hiperonsky/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/hiperonsky/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/a3a5dc8fc46d3b7c3a69/maintainability)](https://codeclimate.com/github/hiperonsky/python-project-49/maintainability)