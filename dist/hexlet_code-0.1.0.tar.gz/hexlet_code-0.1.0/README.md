### Hexlet tests and linter status:
[![Actions Status](https://github.com/hiperonsky/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/hiperonsky/python-project-49/actions)